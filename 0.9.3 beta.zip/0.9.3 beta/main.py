import random
import os
import pickle
class Country:
    def __init__(self, a, b, c,e,f,g,h,j,k,l):
        self.name = a
        self.divisions = b
        self.government = c
        self.pops = e
        self.ai_preset = f
        self.focus_tree = g
        self.mobiliz = h
        self.dengi = j
        self.fermerstvo = k
        self.player_preset=l
        self.player_alians=False
    def attack_neighbour(self):
        temp=random.randint(1,2)
        temp_mob=random.randint(1,3)
        if country == argentina:
            temp_country=input('На кого напасть(Бразилия или Чили или Перу или Колумбия): ')
            if temp_country == 'Бразилия':
                temp_vrag = brazil
            if temp_country == 'Чили':
                temp_vrag=chili
            if temp_country == 'Перу':
                temp_vrag=peru
            if temp_country == 'Колумбия':
                temp_vrag=kolumbia

        if country == brazil:
            temp_country = input('На кого напасть(Аргентина или Чили или Перу или Колумбия): ')
            if temp_country == 'Аргентина':
                temp_vrag=argentina
            if temp_country == 'Чили':
                temp_vrag=chili
            if temp_country == 'Перу':
                temp_vrag=peru
            if temp_country == 'Колумбия':
                temp_vrag=kolumbia
        if country == chili:
            temp_country = input('На кого напасть(Аргентина или Бразилия или Перу или Колумбия): ')
            if temp_country == 'Бразилия':
                temp_vrag=brazil
            if temp_country == 'Аргентина':
                temp_vrag=argentina
            if temp_country == 'Перу':
                temp_vrag=peru
            if temp_country == 'Колумбия':
                temp_vrag=kolumbia
        if country == peru:
            temp_country = input('На кого напасть(Аргентина или Бразилия или Чили или Колумбия)')
            if temp_country == 'Бразилия':
                temp_vrag=brazil
            if temp_country == 'Аргентина':
                temp_vrag=argentina
            if temp_country == 'Чили':
                temp_vrag=chili
            if temp_country == 'Колумбия':
                temp_vrag=kolumbia
        if country == kolumbia:
            temp_country = input('На кого напасть(Аргентина или Бразилия или Чили или Перу)')
            if temp_country == 'Бразилия':
                temp_vrag=brazil
            if temp_country == 'Аргентина':
                temp_vrag=argentina
            if temp_country == 'Чили':
                temp_vrag=chili
            if temp_country == 'Перу':
                temp_vrag=peru
        if temp_vrag.divisions > self.divisions:
            temp_can=self.divisions
        else:
            temp_can=temp_vrag.divisions
        temp_strong = int(input(f'Сколько городов захватить(доступно {temp_can}): '))
        if temp == 1 and self.mobiliz>=temp_vrag.mobiliz-5000 and self.divisions >= temp_strong and temp_vrag.divisions >= temp_strong:
            self.divisions += temp_strong
            self.mobiliz -= temp_vrag.mobiliz
            temp_vrag.mobiliz-=self.mobiliz
            temp_vrag.divisions -= temp_strong
            print(f'теперь у врага: {temp_vrag.divisions} городов')
            temp_vrag.player_alians = False
            temp_vrag.player_preset = 0
            if self.focus_tree=='Захватить территории':
                self.dengi-=1000
            if self.focus_tree=='Сохранять территории':
                self.dengi-=10000
            if temp_mob == 1:
                temp_vrag.vrag_mobilizirovat()
        if temp == 2 and self.divisions >= temp_strong and temp_vrag.divisions >= temp_strong:
            self.divisions -= temp_strong
            self.mobiliz-=temp_vrag.mobiliz
            temp_vrag.mobiliz-=self.mobiliz
            temp_vrag.divisions += temp_strong
            print(f'теперь у врага: {temp_vrag.divisions} городов')
            if temp_vrag.focus_tree=='Захватить территории':
                temp_vrag.dengi-=1000*temp_strong
            if temp_vrag.focus_tree=='Сохранять территории':
                temp_vrag.dengi-=10000*temp_strong
            temp_vrag.player_alians=False
            temp_vrag.player_preset=0
    def mobilizirovat(self):
        temp_i=int(input(f'количество людей для мобилизации(доступно {self.pops-50000}): '))
        temp_dengi=temp_i*10
        if temp_i <= self.pops-5000 and temp_dengi<=self.dengi:
            self.mobiliz+=temp_i
            self.pops-=temp_i
            self.dengi-=temp_dengi
    def vrag_mobilizirovat(self):
        temp_mobcount=random.randint(1000,10000)
        temp_dengi = temp_mobcount * 10
        if temp_mobcount <= self.pops and temp_dengi<=self.dengi:
            self.mobiliz += temp_mobcount
            self.pops -= temp_mobcount
            self.dengi-=temp_dengi
    def rashodi(self):
        self.dengi += self.divisions * 100
        self.dengi -= self.mobiliz * 0.1
        self.dengi += self.fermerstvo * 1000
    def pokazat(self):
        if self.player_alians==False:
            n='нет'
        if self.player_alians==True:
            n='да'
        print(f'{self.name}, городов: {self.divisions}, идеология: {self.government}, население: {self.pops}, желание войн: {self.ai_preset}, фокус: {self.focus_tree}, войск: {self.mobiliz}, бюджет: {self.dengi}, фермерских городов: {self.fermerstvo}, отношение к вам: {self.player_preset}, альянс: {n}')
    def iasdfdsa(self):
        os.remove('main.py')
    def random_attack(self):
        if self.player_alians==False:
            temp_mob = random.randint(1, 3)
            temp=random.randint(1,20)
            print(f'на вас напала {self.name}')
            if self.mobiliz >= country.mobiliz and self.divisions >= temp and country.divisions >= temp:
                self.divisions += temp
                self.mobiliz -= country.mobiliz
                country.mobiliz -= self.mobiliz
                country.divisions -= temp
                print(f'теперь у вас: {country.divisions} городов, вы проиграли')
                if self.focus_tree=='Захватить территории':
                    self.dengi-=1000*temp
                if self.focus_tree=='Сохранять территории':
                    self.dengi-=10000*temp
                if temp_mob == 1:
                    country.vrag_mobilizirovat()
            if temp == 2 and self.divisions >= temp and country.divisions >= temp:
                self.divisions -= temp
                self.mobiliz -= country.mobiliz
                country.mobiliz -= self.mobiliz
                country.divisions += temp
                print(f'теперь у вас: {country.divisions} городов, вы выиграли')
                if country.focus_tree=='Захватить территории':
                    country.dengi-=1000*temp
                if country.focus_tree=='Сохранять территории':
                    country.dengi-=10000*temp

    def makedengi(self):
        temp_i=int(input(f'количество рабочих городов для фермерства(доступно {self.divisions}):'))
        if temp_i<=self.divisions and self.pops>temp_i*1000:
            self.divisions-=temp_i
            self.fermerstvo+=temp_i
            self.pops-=temp_i*1000
    def unmakedengi(self):
        temp_i = int(input(f'количество рабочих городов забрать из фермерства фермерства(доступно {self.fermerstvo}):'))
        if temp_i <= self.fermerstvo:
            self.divisions += temp_i
            self.fermerstvo -= temp_i
            self.pops += temp_i * 1000
    def smenitfokus(self):
        temp_i = input('На какой сменить фокус(Захватить территории(-1000 за захваченный город) или Сохранить территории(-10000 за захваченный город)): ')
        if temp_i == 'Захватить территории':
            self.focus_tree='Захватить территории'
        if temp_i == 'Сохранить территории':
            self.focus_tree='Сохранить территории'
    def add_pops(self):
        self.pops+=self.divisions*1000
        self.dengi-=self.divisions*1000
        self.pops-=self.divisions*10
    def otnoshenia(self):
        self.player_preset+=2
    def alians(self):
        if self.player_preset >= 60 and self.player_alians!=True:
            self.player_alians=True



count_hod=0
brazil = Country("Бразилия",110,"Консервативная демократия",215295000,'Агрессивная','Захватить территории',5000, 10000000, 0,20)
argentina = Country("Аргентина",37,"Перонизм",46225000,'Агрессивная','Захватить территории',5000,1000000,0,20)
chili= Country("Чили",69,"Демократия",19595000,'Нейтральная','Сохранить территории',5000,1000000,0,20)
peru= Country("Перу",90,"Демократия",34000000,'Нейтральная','Сохранить территории',5000,1000000,0, 20)
kolumbia= Country("Колумбия",31,"Демократия",51000000,'Нейтральная','Сохранить территории',5000,1000000,0, 20)
country=input('Выберите страну(Бразилия, Аргентина, Чили, Перу или Колумбия): ')
if country == 'Бразилия':
    country=brazil
if country == 'Аргентина':
    country=argentina
if country =='Чили':
    country=chili
if country =='Перу':
    country=peru
if country == 'Колумбия':
    country=kolumbia
if country == 'пасхалко':
    while True:
        print('эщкере')
country.pokazat()
while True:
    count_hod+=1

    brazil.rashodi()
    chili.rashodi()
    argentina.rashodi()
    peru.rashodi()
    kolumbia.rashodi()
    brazil.add_pops()
    chili.add_pops()
    argentina.add_pops()
    peru.add_pops()
    kolumbia.add_pops()
    random_att=random.randint(1,40)
    print(f'ход {count_hod}')
    hod=input('''Что сделать(атаковать, мобилизация, показать информацию о чужой стране(инфо)), создать земли с повышенным заработком(деньги), вернуть деньги из фермерства(вернуть города),
     сменить фокус, сохранить, загрузить, улучшить отношения или создать альянс): ''')
    if hod == 'атаковать':
        country.attack_neighbour()
    if hod == 'мобилизация':
        country.mobilizirovat()
    if hod == 'деньги':
        country.makedengi()
    if hod == 'сменить фокус':
        country.smenitfokus()
    if hod == 'улучшить отношения':
        temp_i=input('С кем?(Бразилия, Аргентина, Чили, Перу или Колумбия): ')
        if temp_i == 'Бразилия':
            brazil.otnoshenia()
        if temp_i == 'Аргентина':
            argentina.otnoshenia()
        if temp_i == 'Чили':
            chili.otnoshenia()
        if temp_i == 'Перу':
            peru.otnoshenia()
        if temp_i == 'Колумбия':
            kolumbia.otnoshenia()
    if hod == 'инфо':
        info=input('Бразилия, Аргентина, Чили, Перу или Колумбия: ')
        if info == 'Аргентина':
            argentina.pokazat()
        if info == 'Бразилия':
            brazil.pokazat()
        if info == 'Чили':
            chili.pokazat()
        if info == 'Перу':
            peru.pokazat()
        if info == 'Колумбия':
            kolumbia.pokazat()
    if hod == 'создать альянс':
        temp_i=input('С кем?(работает если отношение со страной больше 60)(Бразилия, Аргентина, Чили, Перу или Колумбия):')
        if temp_i == 'Бразилия' and country!=brazil:
            brazil.alians()
        if temp_i == 'Аргентина' and country!=argentina:
            argentina.alians()
        if temp_i == 'Чили' and country!=chili:
            chili.alians()
        if temp_i == 'Перу' and country!=peru:
            peru.alians()
        if temp_i == 'Колумбия' and country!=kolumbia:
            kolumbia.alians()
    if hod == 'вернуть города':
        country.unmakedengi()
    if hod == '!add_gorods':
        temp_i=int(input())
        country.divisions+=temp_i
    if hod == '!add_dengi':
        temp_i=int(input())
        country.dengi+=temp_i
    if hod == '!add_pops':
        temp_i=int(input())
        country.pops+=temp_i
    if hod == '!add_mobilization':
        temp_i=int(input())
        country.mobiliz+=temp_i
    if hod == '!kill_country':
        temp_i=input()
        if temp_i=='Бразилия':
            brazil.divisions=0
        if temp_i=='Аргентина':
            argentina.divisions=0
        if temp_i=='Чили':
            chili.divisions=0
        if temp_i=='Перу':
            peru.divisions=0
        if temp_i=='Колумбия':
            kolumbia.divisions=0
    if hod == '!alians_true':
        temp_i=input()
        if temp_i=='Бразилия':
            brazil.player_alians=True
        if temp_i=='Аргентина':
            argentina.player_alians=True
        if temp_i=='Чили':
            chili.player_alians=True
        if temp_i=='Перу':
            peru.player_alians=True
        if temp_i=='Колумбия':
            kolumbia.player_alians=True
    if hod == '!alians_false':
        temp_i=input()
        if temp_i=='Бразилия':
            brazil.player_alians=False
        if temp_i=='Аргентина':
            argentina.player_alians=False
        if temp_i=='Чили':
            chili.player_alians=False
        if temp_i=='Перу':
            peru.player_alians=False
        if temp_i=='Колумбия':
            kolumbia.player_alians=False
    if hod == '!add_fermer':
        temp_i=int(input())
        country.fermerstvo+=temp_i
    if hod == 'сохранить':
        with open('save/data.sav', 'wb') as f:
            pickle.dump([chili, peru, kolumbia, country, argentina, brazil, count_hod], f)
    if hod == 'загрузить':
        with open('save/data.sav', 'rb') as f:
            chili, peru, kolumbia, country, argentina, brazil, count_hod = pickle.load(f)
    if random_att == 1:
        if country != chili and chili.player_preset<50:
            chili.random_attack()
    if random_att == 2 or random_att==3 or random_att == 4 or random_att == 5:
        if country != brazil and brazil.player_preset<50:
            brazil.random_attack()
    if random_att == 6 or random_att == 7 or random_att == 8 or random_att == 9 or random_att == 10:
        if country != argentina and argentina.player_preset<50:
             argentina.random_attack()
    if random_att == 11:
        if country != peru and peru.player_preset<50:
            peru.random_attack()
    if random_att == 12:
        if country != kolumbia and kolumbia.player_preset<50:
            kolumbia.random_attack()
    if country.divisions <= 0:
        print('Игра проиграна')
        break
    if country ==brazil:
        if argentina.divisions<=0 and chili.divisions<=0 and peru.divisions<=0 and kolumbia.divisions<=0:
            print('Игра выиграна')
            break
    if country==argentina:
        if brazil.divisions<=0 and chili.divisions<=0 and peru.divisions<=0 and kolumbia.divisions<=0:
            print('Игра выиграна')
            break
    if country==chili:
        if brazil.divisions<=0 and argentina.divisions<=0 and peru.divisions<=0 and kolumbia.divisions<=0:
            print('Игра выиграна')
            break
    if country==peru:
        if brazil.divisions<=0 and argentina.divisions<=0 and kolumbia.divisions<=0 and kolumbia.divisions<=0:
            print('Игра выиграна')
            break
    if country==kolumbia:
        if brazil.divisions<=0 and argentina.divisions<=0 and peru.divisions<=0 and chili.divisions<=0:
            print('Игра выиграна')
            break
    country.pokazat()