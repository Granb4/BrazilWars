import random
import os
import pickle
#update log
#до 0.9.3 beta.1 - неизвестно
#0.9.3 beta.1 - небольшое изменение механики отношений /в планах добавление английского перевода
#сделать цветной текст
#сделать сложности
import subprocess

choose = input('сложность(легкая, средняя):')
if choose == 'средняя':
    subprocess.run(["python", "medium.py"])
if choose == 'легкая':
    subprocess.run(['python','easy.py'])